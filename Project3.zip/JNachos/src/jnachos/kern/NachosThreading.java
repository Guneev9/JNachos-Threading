//NEW FILE FOR PROJECT3 FOR IMPLEMENTATION  OF THREADING

package jnachos.kern;
import jnachos.machine.*;


/**
 * Thread states in JNachos. JUST_CREATED: The Thread was just created.
 * RUNNING: The Thread is the current Thread. READY: The Thread
 * is waiting to run. KILLED: The Thread has finished and should be
 * killed.
 */
enum ThreadStatus 
{ 
	JUST_CREATED, RUNNING, READY, BLOCKED 
};


/**
 * Routines to manage Threading Process. There are four main operations:
 *
 * Create_Thread: 
 * create a JNachos thread to run a procedure concurrently with the caller
 * (this is done in two steps -- first allocate the thread object, then call
 * this function on it) 
 * finish: 
 * called when the forked procedure finishes, to clean up
 * yield: relinquish control over the CPU to another ready thread. 
 * sleep:
 *relinquish control over the CPU, but the process is now blocked. In other
 * words, it will not run again, until explicitly put back on the ready queue.
 *
 **/
public class NachosThreading
{

	//Used to create unique Thread_id values. Increments to the next integer once a 
	//Th_id value is assigned to a new Thread
	public static int Thread_count = 1;
	
	//A unique Thread  Identification value used to identify each of the threads in the system.
	public int Th_id;
	
	public boolean is_finish= false; 

	/**
	 * The status of the Thread.
	 */
	private ThreadStatus Th_Status;
	
    /**
	 * The name of the Thread.
	 */
	private String Th_Name;
	
	// all registers except for stackTop
	private int[] mUserRegisters;

	/**
	 * User code this thread is running.
	 */
	private AddrSpace mSpace;

	/**
	 * The function to for this thread to run.
	 */
	private VoidFunctionPtr myFunc;

	/**
	 * The parameter to the function.
	 */
	private Object myArg;
	
	/**
	 * Indicates whether or not this thread has already been started.
	 */
	private boolean mStarted;
	
	

//  	Initialize a thread control block
    public NachosThreading(String threadname)
    {
    		//save the thread name
    		Th_Name = threadname;
        Th_Status = ThreadStatus.JUST_CREATED;
        
    }// it initializes a Thread 
    

// This is for creating a thread called by new system calls
// 	"func" is the procedure to run concurrently.
// 	"arg" is a single argument to be passed to the procedure.

	// basic thread operations
    void CreateThread(VoidFunctionPtr pFunc, Object pArg)
    {
    		Debug.print('t', " Thread " + Th_Name + "with func = " + pFunc + ", arg = " + pArg);

		// Capture the current state of the interrupts
    		
		// save the parameters in this thread object
		myFunc = pFunc;
		myArg = pArg;

		// ReadyToRun assumes that interrupts are disabled!
		Scheduler.readyToRun(this);
		
		Interrupt.setLevel(true);
		
		//it calls the thread
		myFunc.call(myArg);
		
		finish();

		Th_id=Thread_count++;
    }
    

	/**
	 * Dispatch the CPU to next thread. Save the state of the old thread, and
	 * load the state of the new thread, by calling the machine dependent
	 * context switch routine, SWITCH.
	 *
	 * Note: we assume the state of the previously running thread has already
	 * been changed from running to blocked or ready (depending). 
	 *
	 * @param T_NextThread
	 *            is the thread to be put into the CPU.
	 **/
	public synchronized void switchThread(NachosThreading T_NextThread) 
	{
		// Getting  the current Thread
		NachosThreading old_Thread = JNachos.getCurrentThread();

		//Do nothing
		if (old_Thread == T_NextThread)
			return;

		// If this Thread's address space is not null
		if (old_Thread.getSpace() != null) 
		{
			// save the user's CPU registers
			old_Thread.saveUserState();

			// save the address's space state
			old_Thread.getSpace().saveState();
		}

		// switch to the next Thread
		JNachos.setCurrentThread(T_NextThread);

		// next Thread is  running now
		T_NextThread.setStatus(ThreadStatus.RUNNING);

		Debug.print('t', "Switching from this Old Thread " + old_Thread.getName() + " to the New Thread " + T_NextThread.getName());

		// Resume the other Thread
		T_NextThread.resume();

		// Stop the current thread
		old_Thread.suspend();

		Debug.print('t', "Now in thread " + T_NextThread.getName());

		// If the old Thread gave up the processor because it was finishing,
		// we need to delete its carcass. Note we cannot delete the Thread
		// before now (for example, in finish()), because up to this
		// point, we were still running on the old Thread's stack!
		if (JNachos.getProcessToBeDestroyed() != null) {
			JNachos.getProcessToBeDestroyed().kill();
			JNachos.setProcessToBeDestroyed(null);
		}

		if (old_Thread.getSpace() != null) 
			
		{
			old_Thread.restoreUserState();
			old_Thread.getSpace().restoreState();
		}
	}
   
//start_Thread
//it will deallocate the previously running thread if it finished 
//enable interrupts

	public void start_Thread()
	{
		boolean oldLevel = Interrupt.setLevel(false);
	    assert(this == JNachos.getCurrentThread());
	    JNachos.setThreadToBeDestroyed(this);
	    
	    Interrupt.setLevel(oldLevel);
	}
    
	
	/**
	 * Resumes this Thread. 
	 */
	
	public synchronized void resume() 
	{
		// If this thread has already begun, simply resume it
		if (mStarted) 
		{
			this.notify();
		} else 
		{
			// If this thread has not yet run, start it
			start_Thread();

			// Remember that we have started it
			mStarted = true;

		}
	}
	
	
	
	/**
	 * Suspend this NachosThreads.
	 *
	 **/
	public void suspend() 
	{
		try 
		{
			this.wait();
		} 
		
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	


// It Relinquishes the CPU if any other thread is ready to run.
//	If so, put the thread on the end of the ready list, so that
//	it will eventually be re-scheduled.
//
//	NOTE: returns immediately if no other thread on the ready queue.
//	Otherwise returns when the thread eventually works its way
//	to the front of the ready list and gets re-scheduled.
//
//	NOTE: we disable interrupts, so that looking at the thread
//	on the front of the ready list, and switching to it, can be done
//	atomically.  On return, we re-set the interrupt level to its
//	original state, in case we are called with interrupts disabled. 
//
// 	Similar to Thread::Sleep(), but a little different.
    
   public void yield()  		
   {
	   NachosThreading Next_Thread;

		// Turn off interrupts
		boolean oldLevel = Interrupt.setLevel(false);

		// Only the currently executing Thread can yield
		assert (this == JNachos.getCurrentThread());

		Debug.print('t', "Yield Thread " + getName());

		//it will Find the next Thread to run
		Next_Thread = Scheduler.findNextToRun();

		// If there is a thread or not
		if (Next_Thread != null) 
		{
			// It will Mark this Thread as ready
			Scheduler.readyToRun(this);

			//It will Run the other threads
			JNachos.getCurrentThread().switchThread(Next_Thread);
		}

		// Return interrupts to their pre-call level
		Interrupt.setLevel(oldLevel);
   }
   
   

//	It will Relinquish the CPU, because the current thread has either
//	finished or is blocked waiting on a synchronization 
//	variable (Semaphore, Lock, or Condition).  In the latter case,
//	eventually some thread will wake this thread up, and put it
//	back on the ready queue, so that it can be re-scheduled.
//
//	NOTE: if there are no threads on the ready queue, that means
//	we have no thread to run.  "Interrupt::Idle" is called
//	to signify that we should idle the CPU until the next I/O interrupt
//	occurs (the only thing that could cause a thread to become
//	ready to run).
//
//	NOTE: we assume interrupts are already disabled, because it
//	is called from the synchronization routines which must
//	disable interrupts for atomicity.We need interrupts off 
//	so that there can't be a time slice between pulling the first thread
//	off the ready list, and switching to it.
   
    public void sleep()
    {
    			NachosThreading Next_Thread;

    			// Only the currently executing thread can sleep
    			assert (this == JNachos.getCurrentThread());

    			// interrupts should already be disabled
    			assert (Interrupt.getLevel() == false);

    			Debug.print('t', "Thread is Sleeping" + getName());

    			// Set the status for this Thread to be blocked
    			Th_Status = ThreadStatus.BLOCKED;

    			// no one to run, wait for an interrupt
    			while ((Next_Thread = Scheduler.findNextToRun()) == null) 
    			{
    				Interrupt.idle();
    			}

    			// returns when we've been signalled
    			JNachos.getCurrentThread().switchThread(Next_Thread);

    }

    /**
	 * Called when a Thread is done executing the thread creation part.
	 *
	 **/
	public void finish() 
	{
		// Turn off interrupts
		Interrupt.setLevel(false);

		// Threads can only kill themselves
		assert (this == JNachos.getCurrentThread());

		Debug.print('t', "Finishing Thread " + getName());

		// Mark this thread as to be destroyed
		JNachos.setThreadToBeDestroyed(this);

		// Put it to sleep
		sleep();
		
		is_finish=true;
		
	}
	
	
	/**
	 * Sets the status of the Thread.
	 * 
	 * @param Th_Status
	 *            Sets the status of this Thread to the parameter
	 **/
	public void setStatus(ThreadStatus t_Status) 
	{
		Th_Status = t_Status;
	}
	
	
	/**
	 * Gets the name for this thread.
	 * 
	 * @return String the name for this thread.
	 */
	public String getName() 
	{
		return Th_Name;
	}
	
	
	/**
	 * Gets the name for this thread.
	 * 
	 * @return Prints the name for this thread.
	 */
    public void Print() 
    { 
    	System.out.println( Th_Name); 
    	}
    

/**
Thread::SaveUserState
Save the CPU state of a user program on a context switch.
Note that a user program thread has *two* sets of CPU registers -- 
one for its state while executing user code, one for its state 
while executing kernel code.  This routine saves the former.
 **/
public void saveUserState()
{
	for (int i = 0; i < Machine.NumTotalRegs; i++) 
	{
		mUserRegisters[i] = Machine.readRegister(i);
	}
}

/**
 * Restore the CPU state of a user program on a context switch.
 *
 **/
public void restoreUserState() 
{
	for (int i = 0; i < Machine.NumTotalRegs; i++) 
	{
		Machine.writeRegister(i, mUserRegisters[i]);
	}
}

/**
 * get Thread status
 * @return thread Status
 * 
 */
public ThreadStatus getStatus() 
{
	return Th_Status;
}


/**
 * De-allocate a Thread. NOTE: the current Thread *cannot* delete itself
 * directly, since it is still running on the stack that we need to delete.
 *
 * NOTE: if this is the main Thread, we can't delete the stack because we
 * didn't allocate it -- we got it automatically as part of starting up Nachos
 *
 **/
public void kill()
{
	
	Debug.print('t', "Deleting the thread " + Th_Name);
	
	assert (this != JNachos.getCurrentThread());
	
	if (mSpace != null) 
	{
	}   
}

/**
 * Sets the address space for this Thread.
 * 
 * @param Sets
 *            the address space for this Thread
 *
 **/
public void setSpace(AddrSpace T_Addr) 
{
	mSpace = T_Addr;
}

/**
 * Gets the address space for this thread.
 * 
 * @return the address for this thread
 **/
public AddrSpace getSpace() 
{
	return mSpace;
}



}

//End of NachosThreading Class



