package jnachos.kern;


//This is new Class order to avoid changes in existing code

public class CreatedThread implements VoidFunctionPtr 
{
	public void call(Object pArg)
	{
		
		//Restore Registers for this thread
		JNachos.getCurrentThread().restoreUserState();
		
		//it will restore address space for this thread 
		JNachos.getCurrentThread().getSpace().restoreState();
		
	}	
			
	}