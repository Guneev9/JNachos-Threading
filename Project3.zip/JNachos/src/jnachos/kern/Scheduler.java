/**  
 *  Copyright (c) 1992-1993 The Regents of the University of California.
 *  All rights reserved.  See copyright.h for copyright notice and limitation 
 *  of liability and disclaimer of warranty provisions.
 *
 *  Created by Patrick McSweeney on 12/5/08.
 *  Copyright 2008 Patrick J. McSweeney All rights reserved.
 */
package jnachos.kern;

import java.util.LinkedList;

/**
 * Routines to choose the next process to run, and to dispatch to that process.
 * 
 * These routines assume that interrupts are already disabled. If interrupts are
 * disabled, we can assume mutual exclusion (since we are on a uniprocessor).
 * 
 * NOTE: We can't use Locks to provide mutual exclusion here, since if we needed
 * to wait for a lock, and the lock was busy, we would end up calling
 * FindNextToRun(), and that would put us in an infinite loop.
 * 
 * Very simple implementation -- no priorities, straight FIFO. Might need to be
 * improved in later assignments.
 * 
 */
public class Scheduler {
	/**
	 * The list of ready to run thread.
	 */
	private static LinkedList<NachosThreading> readyList;

	/**
	 * Initialize the list of ready but not running thread to empty.
	 */
	Scheduler() 
	{
		// Create a list of the threads
		readyList = new LinkedList<NachosThreading>();
	}

	/**
	 * De-allocate the list of ready threads.
	 */
	public static void killScheduler() 
	{
		// Iterate through the list of ready thread
		while (!readyList.isEmpty()) 
		{
			// Remove the next thread from the list
			NachosThreading proc = readyList.removeFirst();

			// Kill this thread
			proc.kill();
		}

		// Mark the ready list as null
		readyList = null;
	}

	/**
	 * Mark a thread as ready, but not running. Put it on the ready list, for
	 * later scheduling onto the CPU.
	 *
	 * @param tThread
	 *            is the thread to be put on the ready list.
	 **/
	public static void readyToRun(NachosThreading tThread) //....................PROJECT3
	{
		Debug.print('t', "Putting the Thread " + tThread.getName() + " on ready list.\n");

		// Mark this process as ready to run
		tThread.setStatus(ThreadStatus.READY);

		// Add this process to the list of process
		readyList.addLast(tThread);
		
	}

	/**
	 * Return the next thread to be scheduled onto the CPU. If there are no
	 * ready thread, return NULL. Side effect: thread is removed from the
	 * ready list.
	 * 
	 * @return The next thread that is able to run is returned, null if non.
	 **/
	public static NachosThreading findNextToRun() 
	{
		// If the list is empty return null
		if (readyList.isEmpty())
			return null;

		// Return the head of the list
		return readyList.removeFirst();
	}

	/**
	 * Print the scheduler state -- in other words, the contents of the ready
	 * list. For debugging.
	 **/
	public static void Print() 
	{
		System.out.println("Ready list contents:\n");
		for (NachosThreading np : readyList) 
		{
			System.out.println(np);
		}
	}
}
